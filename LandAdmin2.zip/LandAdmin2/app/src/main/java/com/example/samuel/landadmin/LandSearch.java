package com.example.samuel.landadmin;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class LandSearch extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_land_search);
    }
}
