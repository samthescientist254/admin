package com.example.samuel.landadmin;

public class SaveData {
    String Name,Residence;
    String Year,IdNo;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getResidence() {
        return Residence;
    }

    public void setResidence(String residence) {
        Residence = residence;
    }

    public String getYear() {
        return Year;
    }

    public void setYear(String year) {
        Year = year;
    }

    public String getIdNo() {
        return IdNo;
    }

    public void setIdNo(String idNo) {
        IdNo = idNo;
    }

    public SaveData(String name, String residence, String year, String idNo){
        this.Name=name;
        this.IdNo=idNo;
        this.Residence=residence;
        this.Year=year;
    }
}

