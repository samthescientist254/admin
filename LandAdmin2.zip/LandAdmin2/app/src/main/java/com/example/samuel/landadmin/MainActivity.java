package com.example.samuel.landadmin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
private Button add_data,pricing,real_estate,search;
ProgressDialog progressDialog;
private EditText Et_name,Et_idNo,Et_Year,Et_residence;
DatabaseReference databaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      add_data=findViewById(R.id.BtnSur);
      Et_name=findViewById(R.id.et_name);
      Et_idNo=findViewById(R.id.et_idNo);
      Et_Year=findViewById(R.id.et_experience);
      Et_residence=findViewById(R.id.et_area);
      real_estate=findViewById(R.id.Real_Estate);
      pricing=findViewById(R.id.pricing);
      search=findViewById(R.id.search);
      progressDialog=new ProgressDialog(this);
      progressDialog.setMessage("Saving....");
      databaseReference= FirebaseDatabase.getInstance().getReference().child("Users");
      databaseReference.orderByChild(" user Name").equalTo(String.valueOf(Et_idNo)).addValueEventListener(new ValueEventListener() {
          @Override
          public void onDataChange(DataSnapshot dataSnapshot) {
              if(dataSnapshot.exists()){
                  Toast.makeText(MainActivity.this,"Data already exists",Toast.LENGTH_SHORT).show();
              }
          }

          @Override
          public void onCancelled(DatabaseError databaseError) {

          }
      });
      add_data.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
           addData();
          }
      });
     real_estate.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              startActivity(new Intent(MainActivity.this,RealEstate.class));
          }
      });
     pricing.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             startActivity(new Intent(MainActivity.this,Pricing.class));
         }
     });
     search.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             startActivity(new Intent(MainActivity.this,LandSearch.class));
         }
     });
    }
    public void addData(){
    String Name=Et_name.getText().toString().trim();
    String Residence=Et_residence.getText().toString().trim();
    String Year=Et_Year.getText().toString().trim();
    String IdNo=Et_idNo.getText().toString().trim();
        if(TextUtils.isEmpty(Name)){
            Toast.makeText(MainActivity.this,"Enter your name",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(Residence)){
            Toast.makeText(MainActivity.this,"Enter your Residence",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(Year)){
            Toast.makeText(MainActivity.this,"Enter your years of experience ",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(IdNo)){
            Toast.makeText(MainActivity.this,"Enter your idno",Toast.LENGTH_SHORT).show();
            return;
        }
    progressDialog.show();
    SaveData saveData=new SaveData(Name,Residence,IdNo,Year);
    databaseReference.push().setValue(saveData);
    progressDialog.dismiss();
        Toast.makeText(getApplication(),"data saved",Toast.LENGTH_SHORT).show();
    }
}
